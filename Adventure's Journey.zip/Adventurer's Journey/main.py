import os
import random
import math
import time
import pygame
from pygame import mixer
from playsound import playsound

pygame.init()

gameVersion = "v0.3.1"

inventory = [{"name": "rock", "quantity": 0}, {"name": "stick", "quantity": 0}, {"name": "string", "quantity": 0}, {"name": "log", "quantity": 0}, {"name": "stone", "quantity": 0}, {"name": "iron ore", "quantity": 0}, {"name": "copper ore", "quantity": 0}, {"name": "gold ore", "quantity": 0}]
inventory2 = [{"name": "iron ingot", "quantity": 0}, {"name": "copper ingot", "quantity": 0}, {"name": "gold ingot", "quantity": 0}]
tools = [{"name": "axe", "has": False, "life": 64}, {"name": "pickaxe", "has": False, "life": 64}, {"name": "hammer", "has": False, "life": 32}]
workshopUnlocked = False

def randomOre():
    rnd = random.randint(1, 100)
    rnd2 = random.randint(1, 3)
    if rnd <= 50:
        inventory[5]["quantity"] += rnd2
        print(f"You picked up {rnd2} {inventory[5]['name']}.")
        playsound("Sound/Item/AquireItem.wav")
        print(f"New {inventory[5]['name']} count: {inventory[5]['quantity']}")
        time.sleep(2)
        home()
    elif rnd > 50 and rnd <= 80:
        inventory[6]["quantity"] += rnd2
        print(f"You picked up {rnd2} {inventory[6]['name']}.")
        playsound("Sound/Item/AquireItem.wav")
        print(f"New {inventory[6]['name']} count: {inventory[6]['quantity']}")
        time.sleep(2)
        home()
    elif rnd > 80 and rnd <= 100:
        ore = inventory[5]
        inventory[7]["quantity"] += rnd2
        print(f"You picked up {rnd2} {inventory[7]['name']}.")
        playsound("Sound/Item/AquireItem.wav")
        print(f"New {inventory[7]['name']} count: {inventory[7]['quantity']}")
        time.sleep(2)
        home()

def axeCraft():
    playsound("Sound/Select/Sel1.wav")
    print("\nAxe cost: (2 rocks, 1 stick, 1 string)")
    print("Craft axe?")
    print("1. Yes")
    print("2. No")
    choice = input(">").lower()
    if choice == "1":
        if inventory[0]["quantity"] >= 2 and inventory[1]["quantity"] >= 1 and inventory[2]["quantity"] >= 1:
            if tools[0]["has"] == True:
                print("You already have the axe!")
                playsound("Sound/Select/Err.wav")
                time.sleep(2)
                craft()
            else:
                playsound("Sound/Select/Sel1.wav")
                inventory[0]["quantity"] -= 2
                inventory[1]["quantity"] -= 1
                inventory[2]["quantity"] -= 1
                tools[0]["has"] = True
                print("You crafted the axe.")
                tools[0]["life"] = 64
                playsound("Sound/Item/AquireItem.wav")
                time.sleep(2)
                craft()
        else:
            print("You do not have enough resources!")
            playsound("Sound/Select/Err.wav")
            time.sleep(1)
            craft()
    elif choice == "2":
        playsound("Sound/Select/Sel2.wav")
        craft()
    else:
        playsound("Sound/Select/Err.wav")
        print("Invalid input!")
        craft()

def pickaxeCraft():
    playsound("Sound/Select/Sel1.wav")
    print("\nPickaxe cost: (3 rocks, 2 stick, 1 string)")
    print("Craft pickaxe?")
    print("1. Yes")
    print("2. No")
    choice = input(">").lower()
    if choice == "1":
        if inventory[0]["quantity"] >= 3 and inventory[1]["quantity"] >= 2 and inventory[2]["quantity"] >= 1:
            if tools[1]["has"] == True:
                print("You already have the pickaxe!")
                playsound("Sound/Select/Err.wav")
                time.sleep(2)
                craft()
            else:
                playsound("Sound/Select/Sel1.wav")
                inventory[0]["quantity"] -= 3
                inventory[1]["quantity"] -= 2
                inventory[2]["quantity"] -= 1
                tools[1]["has"] = True
                print("You crafted the pickaxe.")
                tools[1]["life"] = 64
                playsound("Sound/Item/AquireItem.wav")
                time.sleep(2)
                craft()
        else:
            print("You do not have enough resources!")
            playsound("Sound/Select/Err.wav")
            time.sleep(1)
            craft()
    elif choice == "2":
        playsound("Sound/Select/Sel2.wav")
        craft()
    else:
        playsound("Sound/Select/Err.wav")
        print("Invalid input!")
        craft()

def hammerCraft():
    playsound("Sound/Select/Sel1.wav")
    print("\nHammer cost: (2 stones, 1 stick, 2 string)")
    print("Craft hammer?")
    print("1. Yes")
    print("2. No")
    choice = input(">").lower()
    if choice == "1":
        if inventory[4]["quantity"] >= 2 and inventory[1]["quantity"] >= 1 and inventory[2]["quantity"] >= 2:
            if tools[2]["has"] == True:
                print("You already have the pickaxe!")
                playsound("Sound/Select/Err.wav")
                time.sleep(2)
                craft()
            else:
                playsound("Sound/Select/Sel1.wav")
                inventory[3]["quantity"] -= 2
                inventory[1]["quantity"] -= 1
                inventory[2]["quantity"] -= 2
                tools[2]["has"] = True
                print("You crafted the hammer.")
                tools[2]["life"] = 32
                playsound("Sound/Item/AquireItem.wav")
                time.sleep(2)
                craft()
        else:
            print("You do not have enough resources!")
            playsound("Sound/Select/Err.wav")
            time.sleep(1)
            craft()
    elif choice == "2":
        playsound("Sound/Select/Sel2.wav")
        craft()
    else:
        playsound("Sound/Select/Err.wav")
        print("Invalid input!")
        craft()

def stoneSmelt():
    playsound("Sound/Select/Sel1.wav")
    print("\nStone cost: (2 rocks, 1 log)")
    print("Smelt stone?")
    print("1. Yes")
    print("2. No")
    choice = input(">").lower()
    if choice == "1":
        if inventory[0]["quantity"] >= 2 and inventory[3]["quantity"] >= 1:
                playsound("Sound/Select/Sel1.wav")
                inventory[0]["quantity"] -= 2
                inventory[3]["quantity"] -= 1
                print("You smelted stone.")
                inventory[4]["quantity"] += 1
                playsound("Sound/Item/AquireItem.wav")
                time.sleep(2)
                smelt()
        else:
            print("You do not have enough resources!")
            playsound("Sound/Select/Err.wav")
            time.sleep(1)
            smelt()
    elif choice == "2":
        playsound("Sound/Select/Sel2.wav")
        smelt()
    else:
        playsound("Sound/Select/Err.wav")
        print("Invalid input!")
        smelt()

def ironSmelt():
    playsound("Sound/Select/Sel1.wav")
    print("\nIron ingot cost: (1 iron ore, 1 log, requires hammer)")
    print("Smelt iron ingot?")
    print("1. Yes")
    print("2. No")
    choice = input(">").lower()
    if choice == "1":
        if inventory[5]["quantity"] >= 1 and inventory[3]["quantity"] >= 1 and tools[2]["has"] == True:
            if  tools[2]["has"] == True and tools[2]["life"] > 0:
                playsound("Sound/Select/Sel1.wav")
                inventory[5]["quantity"] -= 1
                inventory[3]["quantity"] -= 1
                print("You smelted iron ingot.")
                inventory2[0]["quantity"] += 1
                if tools[2]["life"] <= 0:
                    playsound("Sound/Item/ItemBreak.wav")
                    print("Your hammer broke!")
                else:
                    playsound("Sound/Item/AquireItem.wav")
                time.sleep(2)
                smelt()
            else:
                print("You don't have the hammer!")
                playsound("Sound/Select/Err.wav")
                time.sleep(1)
                smelt()
        else:
            print("You do not have enough resources!")
            playsound("Sound/Select/Err.wav")
            time.sleep(1)
            smelt()
    elif choice == "2":
        playsound("Sound/Select/Sel2.wav")
        smelt()
    else:
        playsound("Sound/Select/Err.wav")
        print("Invalid input!")
        smelt()

def copperSmelt():
    playsound("Sound/Select/Sel1.wav")
    print("\nCopper ingot cost: (1 copper ore, 1 log, requires hammer)")
    print("Smelt Copper ingot?")
    print("1. Yes")
    print("2. No")
    choice = input(">").lower()
    if choice == "1":
        if inventory[6]["quantity"] >= 1 and inventory[3]["quantity"] >= 1 and tools[2]["has"] == True:
            if  tools[2]["has"] == True and tools[2]["life"] > 0:  
                playsound("Sound/Select/Sel1.wav")
                inventory[6]["quantity"] -= 1
                inventory[3]["quantity"] -= 1
                print("You smelted copper ingot.")
                inventory2[1]["quantity"] += 1
                if tools[2]["life"] <= 0:
                    playsound("Sound/Item/ItemBreak.wav")
                    print("Your hammer broke!")
                else:
                    playsound("Sound/Item/AquireItem.wav")
                playsound("Sound/Item/AquireItem.wav")
                time.sleep(2)
                smelt()
            else:
                print("You don't have the hammer!")
                playsound("Sound/Select/Err.wav")
                time.sleep(1)
                smelt()
        else:
            print("You do not have enough resources!")
            playsound("Sound/Select/Err.wav")
            time.sleep(1)
            smelt()
    elif choice == "2":
        playsound("Sound/Select/Sel2.wav")
        smelt()
    else:
        playsound("Sound/Select/Err.wav")
        print("Invalid input!")
        smelt()

def goldSmelt():
    playsound("Sound/Select/Sel1.wav")
    print("\nGold ingot cost: (1 gold ore, 1 log, requires hammer)")
    print("Smelt Gold ingot?")
    print("1. Yes")
    print("2. No")
    choice = input(">").lower()
    if choice == "1":
        if inventory[76]["quantity"] >= 1 and inventory[3]["quantity"] >= 1 and tools[2]["has"] == True:
            if  tools[2]["has"] == True and tools[2]["life"] > 0:  
                playsound("Sound/Select/Sel1.wav")
                inventory[7]["quantity"] -= 1
                inventory[3]["quantity"] -= 1
                print("You smelted gold ingot.")
                inventory2[2]["quantity"] += 1
                if tools[2]["life"] <= 0:
                    playsound("Sound/Item/ItemBreak.wav")
                    print("Your hammer broke!")
                else:
                    playsound("Sound/Item/AquireItem.wav")
                playsound("Sound/Item/AquireItem.wav")
                time.sleep(2)
                smelt()
            else:
                print("You don't have the hammer!")
                playsound("Sound/Select/Err.wav")
                time.sleep(1)
                smelt()

        else:
            print("You do not have enough resources!")
            playsound("Sound/Select/Err.wav")
            time.sleep(1)
            smelt()
    elif choice == "2":
        playsound("Sound/Select/Sel2.wav")
        smelt()
    else:
        playsound("Sound/Select/Err.wav")
        print("Invalid input!")
        smelt()

def craft():
    global inventory
    print("\nCrafting")
    print("You have the following resources:")
    for item in inventory:
        print(f"{item['name']} - Quantity: {item['quantity']}")
    for item in inventory2:
        print(f"{item['name']} - Quantity: {item['quantity']}")
    for item in tools:
        print(f"{item['name']} - Has: {item['has']} - Durablity: {item['life']}")
    print("\nYou can craft the following items:")
    print("1. Axe")
    print("2. Pickaxe")
    print("3. Hammer")
    print("4. Return home")
    choice = input(">").lower()
    if choice == "1":
        axeCraft()
    elif choice == "2":
        pickaxeCraft()
    elif choice == "3":
        hammerCraft()
    elif choice == "4":
        playsound("Sound/Select/Sel2.wav")
        home()
    else:
        playsound("Sound/Select/Err.wav")
        print("Invalid input!")
        craft()

def travel():
    print("\nYou are traveling.")
    print("1. Cave")
    print("2. Forest")
    print("3. Abandoned house")
    print("4. Home")
    choice = input(">").lower()
    if choice == "1":
        playsound("Sound/Select/Sel1.wav")
        cave()
    elif choice == "2":
        playsound("Sound/Select/Sel1.wav")
        forest()
    elif choice == "3":
        playsound("Sound/Select/Sel1.wav")
        abandonedHouse()
    elif choice == "4":
        playsound("Sound/Select/Sel2.wav")
        home()
    else:
        playsound("Sound/Select/Err.wav")
        print("Invalid input!")
        travel()

def smelt():
    global inventory
    print("\nSmelting")
    print("You have the following resources:")
    for item in inventory:
        print(f"{item['name']} - Quantity: {item['quantity']}")
    for item in inventory2:
        print(f"{item['name']} - Quantity: {item['quantity']}")
    for item in tools:
        print(f"{item['name']} - Has: {item['has']} - Durablity: {item['life']}")
    print("\nYou can smelt the following items:")
    print("1. Stone")
    print("2. Iron ingot")
    print("3. Copper ingot")
    print("4. Gold ingot")
    print("5. Return home")
    choice = input(">").lower()
    if choice == "1":
        stoneSmelt()
    elif choice == "2":
        ironSmelt()
    elif choice == "3":
        copperSmelt()
    elif choice == "4":
        goldSmelt()
    elif choice == "5":
        playsound("Sound/Select/Sel2.wav")
        home()
    else:
        playsound("Sound/Select/Err.wav")
        print("Invalid input!")
        smelt()

def home():
    print("\nYou are home.")
    print("1. Travel")
    print("2. Check inventory")
    print("3. Craft")
    print("4. Exit game")
    choice = input(">").lower()
    if choice == "1":
        playsound("Sound/Select/Sel1.wav")
        travel()
    elif choice == "2":
        print("\nInventory")
        playsound("Sound/Select/Sel1.wav")
        for item in inventory:
            print(f"{item['name']} - Quantity: {item['quantity']}")
        for item in inventory2:
            print(f"{item['name']} - Quantity: {item['quantity']}")
        for item in tools:
            print(f"{item['name']} - Has: {item['has']} - Durablity: {item['life']}")
        else:
            input("Press enter to continue>")
            home()
    elif choice == "3":
        playsound("Sound/Select/Sel1.wav")
        craft()
    elif choice == "4":
        print("Goodbye!")
        time.sleep(2)
        pygame.quit()
        exit()
    else:
        print("Invalid input!")
        playsound("Sound/Select/Err.wav")
        home()

def workshop():
    print("\nYou are in the workshop.")
    print("1. Smelt ore")
    print("2. Go home")
    choice = input(">").lower()
    if choice == "1":
        playsound("Sound/Select/Sel1.wav")
        smelt()
    elif choice == "2":
        playsound("Sound/Select/Sel2.wav")
        home()
    else:
        print("Invalid input!")
        playsound("Sound/Select/Err.wav")
        home()

def cave():
    global inventory
    print("\nYou are in a cave.")
    print("1. Gather rocks")
    print("2. Mine ore (Requires pickaxe)")
    print("3. Go home")
    choice = input(">").lower()
    if choice == "1":
        rnd = random.randint(1, 3)
        print("\nYou picked up the rocks.")
        inventory[0]["quantity"] += rnd
        print(f"You picked up {rnd} rocks.")
        playsound("Sound/Item/AquireItem.wav")
        print(f"New rock count: {inventory[0]['quantity']}")
        time.sleep(2)
        home()
    elif choice == "2":
        if tools[1]["has"] == True and tools[1]["life"] > 0:
            rnd = random.randint(1, 3)
            print("\nYou you mined the ore.")
            inventory[3]["quantity"] += rnd
            tools[1]["life"] -= rnd
            if tools[1]["life"] <= 0:
                tools[1]["has"] = False
                print("Your pickaxe broke!")
                playsound("Sound/Item/ItemBreak.wav")
            randomOre()
            if tools[1]["has"] == True:
                print(f"Axe life: {tools[0]['life']}")
            time.sleep(2)
            forest()
        else:
            print("You need an pickaxe to mine ore!")
            playsound("Sound/Select/Err.wav")
            time.sleep(2)
            home()
    elif choice == "3":
        playsound("Sound/Select/Sel2.wav")
        home()
    else:  
        print("Invalid input!")
        playsound("Sound/Select/Err.wav")
        cave()

def forest():
    global inventory
    print("\nYou are in a forest.")
    print("1. Gather sticks")
    print("2. Chop tree (Requires axe)")
    print("3. Go home")
    choice = input(">").lower()
    if choice == "1":
        rnd = random.randint(1, 3)
        print("\nYou picked up the sticks.")
        inventory[1]["quantity"] += rnd
        playsound("Sound/Item/AquireItem.wav")
        print(f"You picked up {rnd} sticks.")
        print(f"New stick count: {inventory[1]['quantity']}")
        time.sleep(2)
        home()
    elif choice == "2":
        if tools[0]["has"] == True and tools[0]["life"] > 0:
            rnd = random.randint(1, 3)
            print("\nYou chopped down a tree.")
            inventory[3]["quantity"] += rnd
            tools[0]["life"] -= rnd
            if tools[0]["life"] <= 0:
                tools[0]["has"] = False
                print("Your axe broke!")
                playsound("Sound/Item/ItemBreak.wav")
            else:
                playsound("Sound/Item/AquireItem.wav")
            print(f"You picked up {rnd} logs.")
            print(f"New log count: {inventory[3]['quantity']}")
            if tools[0]["has"] == True:
                print(f"Axe life: {tools[0]['life']}")
            time.sleep(2)
            forest()
        else:
            print("You need an axe to chop down a tree!")
            playsound("Sound/Select/Err.wav")
            time.sleep(2)
            home()
    elif choice == "3":
        playsound("Sound/Select/Sel2.wav")
        home()
    else:
        playsound("Sound/Select/Err.wav")
        print("Invalid input!")
        forest()

def abandonedHouse():
    global inventory
    global workshopUnlocked
    print("\nYou are in an abandoned house.")
    print("1. Pick up string")
    print("2. Workshop")
    print("3. Go home")
    choice = input(">").lower()
    if choice == "1":
        rnd = random.randint(1, 3)
        print("\nYou picked up the string.")
        inventory[2]["quantity"] += rnd
        playsound("Sound/Item/AquireItem.wav")
        print(f"You picked up {rnd} string.")
        print(f"New string count: {inventory[2]['quantity']}")
        time.sleep(2)
        home()
    elif choice == "2":
        playsound("Sound/Select/Sel1.wav")
        if workshopUnlocked == False:
            print("\nYou need to repair the workshop first!")
            print("Workshop repair costs: (5 rocks, 20 logs)")
            print("Repair workshop?")
            print("1. Repair")
            print("2. Return")
            choice = input(">").lower()
            if choice == "1":
                if inventory[0]["quantity"] >= 5 and inventory[3]["quantity"] >= 20:
                    playsound("Sound/Item/AquireItem.wav")
                    workshopUnlocked = True
                    inventory[0]["quantity"] -= 5
                    inventory[3]["quantity"] -= 20
                    print("You repaired the workshop.")
                    time.sleep(2)
                    workshop()
                else:
                    playsound("Sound/Select/Err.wav")
                    print("Not enough resources!")
                    time.sleep(2)
                    abandonedHouse()
            elif choice == "2":
                playsound("Sound/Select/Sel2.wav")
                abandonedHouse()
            else:
                playsound("Sound/Select/Err.wav")
                print("Invalid input!")
                abandonedHouse()
        else:
            playsound("Sound/Select/Sel1.wav")
            workshop()
            
    elif choice == "3":
        playsound("Sound/Select/Sel2.wav")
        home()
    else:
        print("Invalid input!")
        playsound("Sound/Select/Err.wav")
        abandonedHouse()

print("Welcome to the Adventure's Journey!")
print(f"Current version: {gameVersion}")
time.sleep(1)
pygame.mixer.music.load("Sound/Music/Adventure-Bop.wav")
pygame.mixer.music.play(-1)
home()